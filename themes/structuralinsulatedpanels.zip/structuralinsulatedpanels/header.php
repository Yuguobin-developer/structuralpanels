<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <div class="top-header">
      <div class="contact-info">
          <span><i class="fas fa-envelope"></i> EMAIL US </span>
          <span><i class="fas fa-phone"></i> 905-372-0195</span>
      </div>
    </div>
    <!-- Site header section -->
    <header id="site-header" class="site-header container">
        <!-- Display the site logo if available -->
        <?php if (has_custom_logo()) : ?>
            <div class="site-logo">
                <?php the_custom_logo(); ?>
            </div>
        <?php else : ?>
            <div class="site-title">
                <h1><a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></h1>
                <p><?php bloginfo('description'); ?></p>
            </div>
        <?php endif; ?>

        <!-- Display the navigation menu -->
        <?php
        if (has_nav_menu('primary-menu')) {
            wp_nav_menu(array(
                'theme_location' => 'primary-menu',
                'container' => 'nav',
                'container_class' => 'primary-menu',
            ));
        }
        ?>
    </header>
    <!-- End site header section -->

    <!-- Main content area starts here -->
    <main id="main-content" class="main-content">
