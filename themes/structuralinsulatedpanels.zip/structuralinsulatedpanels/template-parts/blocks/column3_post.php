<div class="container">
	<div class="column-blog">
		<?php
			$posts = get_field('column_post');

			foreach ($posts as $post) {

			    $id = $post['each_post']->ID;

			    $featured_image = get_the_post_thumbnail($id);

		        $post_permalink = get_permalink($id);

	    ?>

		<div class="each-blog">
			<div>
		    	<a href="<?php echo $post_permalink; ?>">
		    		<?php echo $featured_image; ?>
				</a>
			</div>
	    	<div class="title"><?php echo $post['each_post']->post_title ; ?></div>	
	    	<div class="expert"><?php echo $post['each_post']->post_excerpt ; ?></div>	

			<div class="button-learn">
				<a href="<?php echo $post_permalink; ?>">LEARN MORE</a> 
			</div>
		</div>
		<?php
			}
		?>
	</div>
</div>
<style type="text/css">
	.column-blog {
		margin: 4rem 0;
		width: 100%;
	    display: grid;
	    grid-template-columns: repeat(3, 1fr);
	    grid-gap: 3.5rem;
	}
	.each-blog {
	}
	.each-blog img {
		width: 100%;
		max-height: 400px;
	}
	.title {
		font-size: 1.5rem;
		font-weight: 700;
		padding: 1rem 0;
	}
	.button-learn {
		margin: 2rem 0;
	}
	.button-learn a{
	    text-decoration: none;
	    font-weight: 600;
	    border: solid 2px;
	    padding: 10px 20px;
	    border-radius: 30px;
	}
</style>



