<div class="total-blog" style="background-image: url('<?php echo get_field('grid_post')['background_image']; ?>');">
	<div class="title">
		<?php
			echo get_field('grid_post')['title'];
		?>
	</div>
	<div class="description">
		<?php
			echo get_field('grid_post')['description'];
		?>
	</div>
	<div class="container blog-post" style="display: flex; grid-gap: 2.5rem;">
		<div class="right-side" style="width: 50%;">
			<?php
				$posts = get_field('grid_post')['posts_right'];
				$id = $posts->ID;
			    $featured_image = get_the_post_thumbnail($id);

			        // Get the permalink (link) to the post
			        $post_permalink = get_permalink($id);

			?>
		    <a href="<?php echo $post_permalink; ?>">
			    <?php echo $featured_image; ?>
			</a>
	    	<div class="article-title"><?php echo $posts->post_title ; ?></div>	
		</div>
		<div class="left-side" style="width: 50%;">
			<?php
				$posts = get_field('grid_post')['posts_left'];

				foreach ($posts as $post) {

				    $id = $post['post']->ID;

				    $featured_image = get_the_post_thumbnail($id);

			        $post_permalink = get_permalink($id);

	        ?>

        	<a href="<?php echo $post_permalink; ?>">
        		<?php echo $featured_image; ?>
	    		<div class="article-title"><?php echo $post['post']->post_title ; ?></div>	
			</a>
	    	<?php
				}
			?>
		</div>
	</div>
	<div style="display: flex;">
		<a class="view-button" href="<?php echo get_field('grid_post')['button']['url'];?>" style="background-color: <?php echo get_field('grid_post')['button']['color'];?>; ">
			<?php echo get_field('grid_post')['button']['text'];?>
		</a>
		
	</div>
</div>
<style type="text/css">
	.view-button{
	    background-color: #db562e;
	    border-radius: 30px;
	    padding: 16px 34px;
	    text-decoration: none;
	    color: white;
	    font-weight: 600;
	    margin: 3rem auto;
	}
	.left-side {
		width: 50%;
	    display: grid;
	    grid-template-columns: repeat(2, 1fr);
	    grid-gap: 2.5rem;
	}
	.right-side {
		width: 50%;	
	}
	.right-side img {
		width: 100%;
		height: 45vw;
	}
	.left-side img {
		width: 100%;
    	height: 12.85vw;
	}
	.total-blog {
		background-size: cover;
		background-repeat: no-repeat;
	}
	.total-blog .title h1 {
		font-size: 3.5rem;
		color: white;    
		margin: 0;
    	padding-top: 4.5rem;
	}
	.total-blog .description p {
		font-size: 1.2rem;
		color: white;
		padding-bottom: 2rem;
	}
	.article-title {
	    margin-top: -50px;
	    color: #fff;
	    font-size: 1.3rem;
	    font-weight: 600;
	    margin-left: 25px;
	}
</style>



