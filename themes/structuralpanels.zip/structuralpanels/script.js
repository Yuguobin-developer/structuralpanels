jQuery(window).load(function(){
	jQuery("body").find('a[href="#get-started-cta"]').addClass('fancybox-inline');

	
	});

